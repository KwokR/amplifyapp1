**To delete a Custom Authorizer in an API**

Command::

  aws apigateway delete-authorizer --rest-api-id 1234123412 --authorizer-id 7gkfbo
